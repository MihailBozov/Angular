

export interface UserRoles {
  admin:boolean;
}
